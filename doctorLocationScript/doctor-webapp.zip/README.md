# Doctor Location Script

This project contains a single script, `doctorScript.py`, that finds doctors’ offices within a radius of a given latitude/longitude and outputs a list of offices containing:

- Name
- Address
- Phone number (when available)
- Website (when available)

It also supports persistence by saving the results to:
- a **tab-delimited text file** (always)
- an optional **CSV export** (if you provide `--out-csv`)

Under the hood, it uses the **Google Places API (New)**:
- Nearby Search (New) to find places near your coordinates
- Place Details (New) to fetch phone numbers and website URLs for each place

---

## Prerequisites

### Python 3

On Ubuntu / WSL / Linux:

~~~
python3 --version
~~~

### Mac OS

~~~
python3 --version
~~~

### Windows

~~~
python3 --version
~~~

### Install Dependencies

~~~
pip install requests
pip3 install requests
~~~

### Google Maps Platform API KEY

~~~
export GOOGLE_MAPS_API_KEY="YOUR_API_KEY_HERE"
~~~

### Persisting across terminal sessions

~~~
echo 'export GOOGLE_MAPS_API_KEY="YOUR_API_KEY_HERE"' >> ~/.bashrc
source ~/.bashrc
~~~

### Running the Script

Required arguments
~~~
Argument	Description
--lat	Latitude (example: 40.7128)
--lng	Longitude (example: -74.0060)
--miles	Radius in miles (example: 5)
~~~

~~~
python3 doctorScript.py \
  --lat 40.7128 \
  --lng -74.0060 \
  --miles 5 \
  --max-results 20 \
  --out-txt nyc_doctors.txt \
  --out-csv nyc_doctors.csv
~~~

### Sample Output

**Name,Address,Phone,Website**

~~~
Name,Address,Phone,Website
Mount Sinai-Union Square,"10 Union Sq E, New York, NY 10003, USA",,https://www.mountsinai.org/locations/union-square/services?utm_source=Yext&utm_medium=local_listing&utm_campaign=PACC&y_source=1_MTgwODM0NC03MTUtbG9jYXRpb24ud2Vic2l0ZQ%3D%3D
Spring Street Dermatology - SOHO,"75 Spring St Floor 2, New York, NY 10012, USA",(646) 906-9614,https://springstderm.com/?utm_source=seo_gmb&utm_medium=gmb&utm_campaign=home_page
Gouverneur Health Care Services: Imperato Anna MD,"227 Madison St, New York, NY 10002, USA",(212) 238-7680,
"NYC Health + Hospitals/Gotham Health, Gouverneur","227 Madison St, New York, NY 10002, USA",(844) 692-4692,https://www.nychealthandhospitals.org/locations/gotham-health-gouverneur/
Sky Dental,"111 Broadway Suite 1304, New York, NY 10006, USA",(212) 600-1996,https://skydentalnyc.com/?utm_campaign=gmb
"Tribeca Oral and Maxillofacial Surgery, PLLC","21 Murray St 2nd floor, New York, NY 10007, USA",(212) 267-3300,https://www.tribecaoralsurgery.com/
Expert Dental - Tribeca,"43 Warren St, New York, NY 10007, USA",(212) 540-2258,https://www.expertdentalnyc.com/
Tribeca Skin Center,"315 Church St 2nd floor, New York, NY 10013, USA",(212) 334-3774,http://www.tribecaskincenter.com/
Smile Lab,"841 Broadway, Manhattan, NY 10003, USA",(332) 286-4318,https://smilelabny.com/?utm_campaign=gbp-listing
Eyes on Second,"170 2nd Ave, New York, NY 10003, USA",(212) 600-9279,https://www.eyesonsecond.com/
Tribeca Dental Care,"402 Broadway, New York, NY 10013, USA",(212) 431-4582,https://tribecanydentistoffice.com/
Tribeca Park Dermatology,"32 Ericsson Pl, New York, NY 10013, USA",(212) 374-9750,http://www.triparkderm.com/
The Exchange Dental Group,"39 Broadway Rm 2115, New York, NY 10006, USA",(646) 780-5410,https://www.theexchangedentalgroup.com/
"NYC Health + Hospitals/Gotham Health, Cumberland","100 N Portland Ave, Brooklyn, NY 11205, USA",(844) 692-4692,https://www.nychealthandhospitals.org/locations/gotham-health-cumberland/
Washington Square Dermatology,"18 Washington Square N, New York, NY 10011, USA",(212) 256-1075,http://www.washingtonsqderm.com/
Lenox Hill Radiology | Union Square Diagnostic Imaging,"144 4th Ave, New York, NY 10003, USA",(212) 473-2300,https://www.radnet.com/lenox-hill-radiology/for-patients/request-appointment?utm_source=GMB&utm_medium=LHR_UnionSquare_Web&utm_campaign=GMB_LHR_UnionSquare
Tribeca Pediatrics,"15 Warren St, New York, NY 10007, USA",(212) 226-7666,https://www.tribecapediatrics.com/
The Dermatology Specialists - Greenwich Village,"214 Sullivan St, New York, NY 10012, USA",(212) 385-3700,https://www.thedermspecs.com/locations/greenwich-village/
CP,"155 Canal St, New York, NY 10013, USA",(212) 431-9010,http://cpadvancedimaging.com
Charles B. Wang Community Health Center,"268 Canal St, New York, NY 10013, USA",(212) 379-6998,https://www.cbwchc.org/
~~~

## Web App Version

### Running the App

~~~
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and set GOOGLE_MAPS_API_KEY=...

python3 app.py
~~~

## Docker (Containerized) Version

 - Install docker Desktop for Mac, Windows, linux etc

~~~
docker compose up --build
~~~

- Open web browser at this location: http://localhost:8080

~~~
http://localhost:8080
~~~

